export interface Ingredient {
  id: string;
  name: string;
  quantity: number;
  unit: 'g' | 'kg' | 'ml' | 'l' | 'sdm' | 'sdt' | 'pcs' | 'butir' | 'siung' | 'lembar' | 'batang' | 'buah' | 'potong';
  note?: string;
  category: 'sayur' | 'protein' | 'bumbu' | 'karbo' | 'dairy' | 'lainnya';
}

export interface Step {
  id: string;
  order: number;
  instruction: string;
  image?: string;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  image: string;
  images?: string[];
  servings: number;
  prepTime: number; // in minutes
  cookTime: number; // in minutes
  difficulty: 'mudah' | 'sedang' | 'sulit';
  category: string;
  tags: string[];
  ingredients: Ingredient[];
  steps: Step[];
  nutrition?: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  rating: number;
  reviewCount: number;
  favoriteCount: number;
  authorId: string;
  authorName: string;
  createdAt: string;
  updatedAt: string;
  videoUrl?: string;
  isFeatured?: boolean;
  isTrending?: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  recipeCount: number;
  image?: string;
}

export interface Review {
  id: string;
  recipeId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface ShoppingListItem {
  id: string;
  ingredientName: string;
  quantity: number;
  unit: string;
  category: string;
  checked: boolean;
  recipeIds: string[];
}

export interface ShoppingList {
  id: string;
  name: string;
  items: ShoppingListItem[];
  recipes: { id: string; title: string; servings: number }[];
  createdAt: string;
  updatedAt: string;
}

export interface MenuPlan {
  id: string;
  date: string;
  recipeId: string;
  recipe?: Recipe;
  mealType: 'sarapan' | 'makan-siang' | 'makan-malam' | 'camilan';
}

export type SortOption = 'newest' | 'popular' | 'rating' | 'time';

export interface FilterOptions {
  category?: string;
  tags?: string[];
  difficulty?: string;
  maxTime?: number;
  minRating?: number;
}
