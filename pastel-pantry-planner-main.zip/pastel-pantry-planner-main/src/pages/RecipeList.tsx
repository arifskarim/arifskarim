import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, Filter, X, ChevronDown } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { RecipeCard } from "@/components/recipe/RecipeCard";
import { CategoryCard } from "@/components/recipe/CategoryCard";
import { Button } from "@/components/ui/button";
import { seedRecipes, categories } from "@/data/seedRecipes";
import { cn } from "@/lib/utils";

const sortOptions = [
  { value: "newest", label: "Terbaru" },
  { value: "popular", label: "Paling Populer" },
  { value: "rating", label: "Rating Tertinggi" },
  { value: "time", label: "Waktu Tercepat" },
];

const difficultyOptions = ["mudah", "sedang", "sulit"];

const RecipeList = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "");
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get("category") || "");
  const [selectedDifficulty, setSelectedDifficulty] = useState("");
  const [sortBy, setSortBy] = useState(searchParams.get("sort") || "newest");
  const [showFilters, setShowFilters] = useState(false);

  const filteredRecipes = useMemo(() => {
    let result = [...seedRecipes];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (r) =>
          r.title.toLowerCase().includes(query) ||
          r.description.toLowerCase().includes(query) ||
          r.tags.some((t) => t.toLowerCase().includes(query))
      );
    }

    // Category filter
    if (selectedCategory) {
      result = result.filter((r) => r.category === selectedCategory);
    }

    // Difficulty filter
    if (selectedDifficulty) {
      result = result.filter((r) => r.difficulty === selectedDifficulty);
    }

    // Sorting
    switch (sortBy) {
      case "newest":
        result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case "popular":
        result.sort((a, b) => b.favoriteCount - a.favoriteCount);
        break;
      case "rating":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "time":
        result.sort((a, b) => (a.prepTime + a.cookTime) - (b.prepTime + b.cookTime));
        break;
    }

    return result;
  }, [searchQuery, selectedCategory, selectedDifficulty, sortBy]);

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCategory("");
    setSelectedDifficulty("");
    setSortBy("newest");
    setSearchParams({});
  };

  const hasActiveFilters = searchQuery || selectedCategory || selectedDifficulty;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container px-4 py-8 md:py-12">
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">Semua Resep</h1>
          <p className="text-muted-foreground">
            Temukan resep yang sempurna untuk setiap kesempatan
          </p>
        </div>

        {/* Search & Filters Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="flex-1">
            <div className="search-bar">
              <Search className="w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Cari resep..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery("")}>
                  <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                </button>
              )}
            </div>
          </div>

          {/* Sort & Filter Buttons */}
          <div className="flex gap-2">
            {/* Sort Dropdown */}
            <div className="relative">
              <Button
                variant="outline"
                className="rounded-xl gap-2"
                onClick={() => {}}
              >
                {sortOptions.find((o) => o.value === sortBy)?.label}
                <ChevronDown className="w-4 h-4" />
              </Button>
              <div className="absolute top-full mt-2 right-0 w-48 bg-card rounded-xl shadow-card border border-border p-2 z-20 hidden group-hover:block">
                {sortOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setSortBy(option.value)}
                    className={cn(
                      "w-full text-left px-3 py-2 rounded-lg text-sm transition-colors",
                      sortBy === option.value ? "bg-primary text-primary-foreground" : "hover:bg-muted"
                    )}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter Toggle */}
            <Button
              variant={showFilters ? "default" : "outline"}
              className="rounded-xl gap-2"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="w-4 h-4" />
              Filter
              {hasActiveFilters && (
                <span className="w-2 h-2 rounded-full bg-coral" />
              )}
            </Button>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="bg-card rounded-2xl p-6 mb-8 shadow-soft animate-fade-in">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold">Filter</h3>
              {hasActiveFilters && (
                <Button variant="ghost" size="sm" onClick={clearFilters} className="text-coral">
                  Reset Filter
                </Button>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Categories */}
              <div>
                <label className="block text-sm font-medium mb-3">Kategori</label>
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() =>
                        setSelectedCategory(selectedCategory === cat.name ? "" : cat.name)
                      }
                      className={cn(
                        "px-3 py-1.5 rounded-full text-sm font-medium transition-all",
                        selectedCategory === cat.name
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted hover:bg-muted/80"
                      )}
                    >
                      {cat.icon} {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Difficulty */}
              <div>
                <label className="block text-sm font-medium mb-3">Tingkat Kesulitan</label>
                <div className="flex flex-wrap gap-2">
                  {difficultyOptions.map((diff) => (
                    <button
                      key={diff}
                      onClick={() =>
                        setSelectedDifficulty(selectedDifficulty === diff ? "" : diff)
                      }
                      className={cn(
                        "px-4 py-2 rounded-xl text-sm font-medium transition-all capitalize",
                        selectedDifficulty === diff
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted hover:bg-muted/80"
                      )}
                    >
                      {diff}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Sort Options - Mobile */}
            <div className="mt-6 md:hidden">
              <label className="block text-sm font-medium mb-3">Urutkan</label>
              <div className="flex flex-wrap gap-2">
                {sortOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setSortBy(option.value)}
                    className={cn(
                      "px-4 py-2 rounded-xl text-sm font-medium transition-all",
                      sortBy === option.value
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted hover:bg-muted/80"
                    )}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Results Count */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-muted-foreground">
            Menampilkan <span className="font-semibold text-foreground">{filteredRecipes.length}</span> resep
          </p>
        </div>

        {/* Recipe Grid */}
        {filteredRecipes.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredRecipes.map((recipe, index) => (
              <div
                key={recipe.id}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <RecipeCard recipe={recipe} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">🍳</div>
            <h3 className="font-display text-xl font-semibold mb-2">
              Tidak ada resep ditemukan
            </h3>
            <p className="text-muted-foreground mb-6">
              Coba ubah kata kunci atau filter pencarian
            </p>
            <Button onClick={clearFilters} className="btn-primary rounded-xl">
              Reset Filter
            </Button>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default RecipeList;
