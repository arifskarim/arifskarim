import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { 
  ArrowLeft, Clock, Users, ChefHat, Star, Heart, Share2, 
  ShoppingCart, Plus, Minus, Check, Play, Flame, Timer
} from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { seedRecipes } from "@/data/seedRecipes";
import { cn } from "@/lib/utils";

// Import images
import nasiGorengImg from "@/assets/recipes/nasi-goreng.jpg";
import rendangImg from "@/assets/recipes/rendang.jpg";
import sotoAyamImg from "@/assets/recipes/soto-ayam.jpg";
import gadoGadoImg from "@/assets/recipes/gado-gado.jpg";
import esCendolImg from "@/assets/recipes/es-cendol.jpg";
import mieGorengImg from "@/assets/recipes/mie-goreng.jpg";
import ayamGeprekImg from "@/assets/recipes/ayam-geprek.jpg";

const recipeImages: Record<string, string> = {
  "1": nasiGorengImg,
  "2": rendangImg,
  "3": sotoAyamImg,
  "4": gadoGadoImg,
  "5": esCendolImg,
  "6": mieGorengImg,
  "7": ayamGeprekImg,
};

const RecipeDetail = () => {
  const { id } = useParams();
  const recipe = seedRecipes.find((r) => r.id === id);
  const [servings, setServings] = useState(recipe?.servings || 2);
  const [isFavorite, setIsFavorite] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  if (!recipe) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-display font-bold mb-4">Resep tidak ditemukan</h1>
          <Link to="/" className="btn-primary">Kembali ke Beranda</Link>
        </div>
      </div>
    );
  }

  const imageUrl = recipeImages[recipe.id] || recipe.image;
  const servingMultiplier = servings / recipe.servings;
  const totalTime = recipe.prepTime + recipe.cookTime;

  const toggleStep = (stepId: string) => {
    setCompletedSteps((prev) =>
      prev.includes(stepId) ? prev.filter((id) => id !== stepId) : [...prev, stepId]
    );
  };

  const calculateIngredient = (qty: number) => {
    const result = qty * servingMultiplier;
    return result % 1 === 0 ? result : result.toFixed(1);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "mudah": return "bg-mint text-secondary-foreground";
      case "sedang": return "bg-butter text-foreground";
      case "sulit": return "bg-coral text-accent-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      sayur: "bg-mint-light",
      protein: "bg-coral-light",
      bumbu: "bg-butter",
      karbo: "bg-peach-light",
      dairy: "bg-lavender",
      lainnya: "bg-muted",
    };
    return colors[category] || "bg-muted";
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pb-20">
        {/* Hero Image */}
        <div className="relative h-[50vh] md:h-[60vh] overflow-hidden">
          <img
            src={imageUrl}
            alt={recipe.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
          
          {/* Back Button */}
          <Link
            to="/"
            className="absolute top-6 left-6 p-3 rounded-full bg-card/80 backdrop-blur-sm hover:bg-card transition-colors shadow-soft"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>

          {/* Actions */}
          <div className="absolute top-6 right-6 flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full bg-card/80 backdrop-blur-sm hover:bg-card"
            >
              <Share2 className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsFavorite(!isFavorite)}
              className={cn(
                "rounded-full backdrop-blur-sm",
                isFavorite ? "bg-coral text-card hover:bg-coral/90" : "bg-card/80 hover:bg-card"
              )}
            >
              <Heart className={cn("w-5 h-5", isFavorite && "fill-current")} />
            </Button>
          </div>
        </div>

        <div className="container px-4 -mt-20 relative z-10">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Header Card */}
              <div className="bg-card rounded-3xl p-6 md:p-8 shadow-card">
                {/* Tags */}
                <div className="flex flex-wrap items-center gap-2 mb-4">
                  <span className={cn("px-3 py-1 rounded-full text-sm font-medium", getDifficultyColor(recipe.difficulty))}>
                    {recipe.difficulty.charAt(0).toUpperCase() + recipe.difficulty.slice(1)}
                  </span>
                  <span className="px-3 py-1 rounded-full text-sm font-medium bg-primary/10 text-primary">
                    {recipe.category}
                  </span>
                  {recipe.isTrending && (
                    <span className="px-3 py-1 rounded-full text-sm font-medium bg-primary text-primary-foreground flex items-center gap-1">
                      <Flame className="w-3 h-3" /> Trending
                    </span>
                  )}
                </div>

                {/* Title */}
                <h1 className="font-display text-3xl md:text-4xl font-bold mb-4">
                  {recipe.title}
                </h1>

                {/* Description */}
                <p className="text-muted-foreground mb-6">{recipe.description}</p>

                {/* Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Timer className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">Persiapan</p>
                      <p className="font-semibold">{recipe.prepTime} menit</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Clock className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">Memasak</p>
                      <p className="font-semibold">{recipe.cookTime} menit</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Users className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">Porsi</p>
                      <p className="font-semibold">{recipe.servings} orang</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Star className="w-5 h-5 text-butter fill-butter" />
                    <div>
                      <p className="text-xs text-muted-foreground">Rating</p>
                      <p className="font-semibold">{recipe.rating} ({recipe.reviewCount})</p>
                    </div>
                  </div>
                </div>

                {/* Author */}
                <div className="flex items-center gap-3 mt-6 pt-6 border-t border-border">
                  <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center">
                    <ChefHat className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">{recipe.authorName}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(recipe.createdAt).toLocaleDateString("id-ID", {
                        day: "numeric",
                        month: "long",
                        year: "numeric",
                      })}
                    </p>
                  </div>
                </div>
              </div>

              {/* Steps */}
              <div className="bg-card rounded-3xl p-6 md:p-8 shadow-card">
                <h2 className="font-display text-2xl font-bold mb-6">Langkah Memasak</h2>
                <div className="space-y-4">
                  {recipe.steps.map((step, index) => (
                    <div
                      key={step.id}
                      onClick={() => toggleStep(step.id)}
                      className={cn(
                        "flex gap-4 p-4 rounded-2xl cursor-pointer transition-all duration-300",
                        completedSteps.includes(step.id)
                          ? "bg-mint/30"
                          : "bg-muted/50 hover:bg-muted"
                      )}
                    >
                      <div
                        className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-colors",
                          completedSteps.includes(step.id)
                            ? "bg-mint text-secondary-foreground"
                            : "bg-primary text-primary-foreground"
                        )}
                      >
                        {completedSteps.includes(step.id) ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <span className="text-sm font-bold">{step.order}</span>
                        )}
                      </div>
                      <p
                        className={cn(
                          "flex-1 transition-all",
                          completedSteps.includes(step.id) && "line-through text-muted-foreground"
                        )}
                      >
                        {step.instruction}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Nutrition */}
              {recipe.nutrition && (
                <div className="bg-card rounded-3xl p-6 md:p-8 shadow-card">
                  <h2 className="font-display text-2xl font-bold mb-6">Informasi Nutrisi</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 rounded-2xl bg-peach-light">
                      <p className="text-2xl font-bold text-foreground">{recipe.nutrition.calories}</p>
                      <p className="text-sm text-muted-foreground">Kalori</p>
                    </div>
                    <div className="text-center p-4 rounded-2xl bg-coral-light">
                      <p className="text-2xl font-bold text-foreground">{recipe.nutrition.protein}g</p>
                      <p className="text-sm text-muted-foreground">Protein</p>
                    </div>
                    <div className="text-center p-4 rounded-2xl bg-butter">
                      <p className="text-2xl font-bold text-foreground">{recipe.nutrition.carbs}g</p>
                      <p className="text-sm text-muted-foreground">Karbohidrat</p>
                    </div>
                    <div className="text-center p-4 rounded-2xl bg-mint-light">
                      <p className="text-2xl font-bold text-foreground">{recipe.nutrition.fat}g</p>
                      <p className="text-sm text-muted-foreground">Lemak</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar - Ingredients */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 bg-card rounded-3xl p-6 shadow-card">
                <h2 className="font-display text-2xl font-bold mb-4">Bahan-bahan</h2>

                {/* Servings Adjuster */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-muted/50 mb-6">
                  <span className="text-sm font-medium">Porsi</span>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-8 h-8 rounded-full"
                      onClick={() => setServings(Math.max(1, servings - 1))}
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="font-bold w-8 text-center">{servings}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-8 h-8 rounded-full"
                      onClick={() => setServings(servings + 1)}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Ingredients List */}
                <div className="space-y-3 mb-6 max-h-[400px] overflow-y-auto pr-2">
                  {recipe.ingredients.map((ing) => (
                    <div
                      key={ing.id}
                      className={cn(
                        "flex items-center justify-between p-3 rounded-xl",
                        getCategoryColor(ing.category)
                      )}
                    >
                      <span className="font-medium">{ing.name}</span>
                      <span className="text-sm text-muted-foreground">
                        {calculateIngredient(ing.quantity)} {ing.unit}
                        {ing.note && ` (${ing.note})`}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Add to Shopping List */}
                <Button className="w-full btn-primary rounded-xl gap-2">
                  <ShoppingCart className="w-5 h-5" />
                  Tambah ke Daftar Belanja
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default RecipeDetail;
