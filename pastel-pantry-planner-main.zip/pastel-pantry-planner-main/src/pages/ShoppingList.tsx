import { useState } from "react";
import { Link } from "react-router-dom";
import { 
  ShoppingCart, Plus, Minus, Trash2, Check, Share2, Copy, 
  ChefHat, ArrowRight, Package
} from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/button";
import { seedRecipes } from "@/data/seedRecipes";
import { ShoppingListItem, Recipe } from "@/types/recipe";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

// Import images
import nasiGorengImg from "@/assets/recipes/nasi-goreng.jpg";
import rendangImg from "@/assets/recipes/rendang.jpg";
import sotoAyamImg from "@/assets/recipes/soto-ayam.jpg";

const recipeImages: Record<string, string> = {
  "1": nasiGorengImg,
  "2": rendangImg,
  "3": sotoAyamImg,
};

const categoryLabels: Record<string, { label: string; color: string }> = {
  sayur: { label: "🥬 Sayuran", color: "bg-mint-light" },
  protein: { label: "🥩 Protein", color: "bg-coral-light" },
  bumbu: { label: "🧄 Bumbu & Rempah", color: "bg-butter" },
  karbo: { label: "🍚 Karbohidrat", color: "bg-peach-light" },
  dairy: { label: "🥛 Dairy", color: "bg-lavender" },
  lainnya: { label: "📦 Lainnya", color: "bg-muted" },
};

const ShoppingList = () => {
  const [selectedRecipes, setSelectedRecipes] = useState<{ recipe: Recipe; servings: number }[]>([
    { recipe: seedRecipes[0], servings: 2 },
    { recipe: seedRecipes[2], servings: 4 },
  ]);
  const [checkedItems, setCheckedItems] = useState<string[]>([]);

  // Generate shopping list from selected recipes
  const generateShoppingList = (): Map<string, ShoppingListItem[]> => {
    const itemsMap = new Map<string, ShoppingListItem>();

    selectedRecipes.forEach(({ recipe, servings }) => {
      const multiplier = servings / recipe.servings;

      recipe.ingredients.forEach((ing) => {
        const key = `${ing.name.toLowerCase()}-${ing.unit}`;
        const existing = itemsMap.get(key);

        if (existing) {
          existing.quantity += ing.quantity * multiplier;
          existing.recipeIds.push(recipe.id);
        } else {
          itemsMap.set(key, {
            id: key,
            ingredientName: ing.name,
            quantity: ing.quantity * multiplier,
            unit: ing.unit,
            category: ing.category,
            checked: false,
            recipeIds: [recipe.id],
          });
        }
      });
    });

    // Group by category
    const grouped = new Map<string, ShoppingListItem[]>();
    itemsMap.forEach((item) => {
      const category = item.category;
      if (!grouped.has(category)) {
        grouped.set(category, []);
      }
      grouped.get(category)!.push(item);
    });

    return grouped;
  };

  const shoppingListGrouped = generateShoppingList();

  const toggleCheck = (itemId: string) => {
    setCheckedItems((prev) =>
      prev.includes(itemId) ? prev.filter((id) => id !== itemId) : [...prev, itemId]
    );
  };

  const updateServings = (recipeId: string, delta: number) => {
    setSelectedRecipes((prev) =>
      prev.map((item) =>
        item.recipe.id === recipeId
          ? { ...item, servings: Math.max(1, item.servings + delta) }
          : item
      )
    );
  };

  const removeRecipe = (recipeId: string) => {
    setSelectedRecipes((prev) => prev.filter((item) => item.recipe.id !== recipeId));
  };

  const copyToClipboard = () => {
    let text = "🛒 Daftar Belanja\n\n";

    shoppingListGrouped.forEach((items, category) => {
      const label = categoryLabels[category]?.label || category;
      text += `${label}\n`;
      items.forEach((item) => {
        const qty = item.quantity % 1 === 0 ? item.quantity : item.quantity.toFixed(1);
        text += `□ ${item.ingredientName} - ${qty} ${item.unit}\n`;
      });
      text += "\n";
    });

    navigator.clipboard.writeText(text);
    toast({
      title: "Berhasil disalin!",
      description: "Daftar belanja telah disalin ke clipboard",
    });
  };

  const shareToWhatsApp = () => {
    let text = "🛒 *Daftar Belanja*\n\n";

    shoppingListGrouped.forEach((items, category) => {
      const label = categoryLabels[category]?.label || category;
      text += `*${label}*\n`;
      items.forEach((item) => {
        const qty = item.quantity % 1 === 0 ? item.quantity : item.quantity.toFixed(1);
        const checked = checkedItems.includes(item.id) ? "✅" : "⬜";
        text += `${checked} ${item.ingredientName} - ${qty} ${item.unit}\n`;
      });
      text += "\n";
    });

    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  const totalItems = Array.from(shoppingListGrouped.values()).flat().length;
  const checkedCount = checkedItems.length;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container px-4 py-8 md:py-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-3xl md:text-4xl font-bold mb-2 flex items-center gap-3">
              <ShoppingCart className="w-8 h-8 text-primary" />
              Daftar Belanja
            </h1>
            <p className="text-muted-foreground">
              {totalItems > 0 
                ? `${checkedCount}/${totalItems} item sudah dicentang` 
                : "Pilih resep untuk membuat daftar belanja"}
            </p>
          </div>

          {totalItems > 0 && (
            <div className="flex gap-2">
              <Button variant="outline" className="rounded-xl gap-2" onClick={copyToClipboard}>
                <Copy className="w-4 h-4" />
                Salin
              </Button>
              <Button className="btn-primary rounded-xl gap-2" onClick={shareToWhatsApp}>
                <Share2 className="w-4 h-4" />
                Bagikan
              </Button>
            </div>
          )}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Shopping List */}
          <div className="lg:col-span-2 space-y-6">
            {totalItems > 0 ? (
              Array.from(shoppingListGrouped.entries()).map(([category, items]) => (
                <div key={category} className="bg-card rounded-2xl overflow-hidden shadow-soft">
                  {/* Category Header */}
                  <div className={cn("px-5 py-3 font-semibold", categoryLabels[category]?.color || "bg-muted")}>
                    {categoryLabels[category]?.label || category}
                    <span className="text-sm font-normal ml-2 text-muted-foreground">
                      ({items.length} item)
                    </span>
                  </div>

                  {/* Items */}
                  <div className="divide-y divide-border">
                    {items.map((item) => {
                      const isChecked = checkedItems.includes(item.id);
                      const qty = item.quantity % 1 === 0 ? item.quantity : item.quantity.toFixed(1);

                      return (
                        <div
                          key={item.id}
                          onClick={() => toggleCheck(item.id)}
                          className={cn(
                            "flex items-center gap-4 px-5 py-4 cursor-pointer transition-all duration-300",
                            isChecked ? "bg-mint/20" : "hover:bg-muted/50"
                          )}
                        >
                          {/* Checkbox */}
                          <div
                            className={cn(
                              "w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all",
                              isChecked
                                ? "bg-mint border-mint text-secondary-foreground"
                                : "border-border"
                            )}
                          >
                            {isChecked && <Check className="w-4 h-4" />}
                          </div>

                          {/* Item Info */}
                          <div className="flex-1">
                            <p className={cn(
                              "font-medium transition-all",
                              isChecked && "line-through text-muted-foreground"
                            )}>
                              {item.ingredientName}
                            </p>
                          </div>

                          {/* Quantity */}
                          <span className={cn(
                            "text-sm font-medium px-3 py-1 rounded-full bg-muted",
                            isChecked && "text-muted-foreground"
                          )}>
                            {qty} {item.unit}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-card rounded-2xl p-12 text-center shadow-soft">
                <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-display text-xl font-semibold mb-2">
                  Belum ada item
                </h3>
                <p className="text-muted-foreground mb-6">
                  Pilih resep di panel samping untuk membuat daftar belanja
                </p>
                <Link to="/recipes">
                  <Button className="btn-primary rounded-xl gap-2">
                    Jelajahi Resep
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            )}
          </div>

          {/* Selected Recipes Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-card rounded-2xl p-6 shadow-soft">
              <h2 className="font-display text-xl font-bold mb-4 flex items-center gap-2">
                <ChefHat className="w-5 h-5 text-primary" />
                Resep Dipilih
              </h2>

              {selectedRecipes.length > 0 ? (
                <div className="space-y-4 mb-6">
                  {selectedRecipes.map(({ recipe, servings }) => (
                    <div
                      key={recipe.id}
                      className="flex items-center gap-3 p-3 rounded-xl bg-muted/50"
                    >
                      <img
                        src={recipeImages[recipe.id] || recipe.image}
                        alt={recipe.title}
                        className="w-14 h-14 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{recipe.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-6 h-6"
                            onClick={() => updateServings(recipe.id, -1)}
                          >
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="text-sm font-medium w-16 text-center">
                            {servings} porsi
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-6 h-6"
                            onClick={() => updateServings(recipe.id, 1)}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        onClick={() => removeRecipe(recipe.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  Belum ada resep dipilih
                </p>
              )}

              <Link to="/recipes">
                <Button variant="outline" className="w-full rounded-xl gap-2">
                  <Plus className="w-4 h-4" />
                  Tambah Resep
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default ShoppingList;
