import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { HeroSection } from "@/components/home/HeroSection";
import { RecipeSection } from "@/components/home/RecipeSection";
import { CategorySection } from "@/components/home/CategorySection";
import { FeaturesSection } from "@/components/home/FeaturesSection";
import { CTASection } from "@/components/home/CTASection";
import { getLatestRecipes, getPopularRecipes, getTrendingRecipes, categories } from "@/data/seedRecipes";

const Index = () => {
  const latestRecipes = getLatestRecipes(4);
  const popularRecipes = getPopularRecipes(4);
  const trendingRecipes = getTrendingRecipes();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main>
        <HeroSection />
        
        {/* Trending Recipes */}
        {trendingRecipes.length > 0 && (
          <RecipeSection
            title="🔥 Sedang Trending"
            subtitle="Resep yang sedang populer minggu ini"
            recipes={trendingRecipes.slice(0, 4)}
            viewAllLink="/recipes?filter=trending"
            variant="featured"
          />
        )}

        {/* Categories */}
        <CategorySection categories={categories} />

        {/* Latest Recipes */}
        <RecipeSection
          title="Resep Terbaru"
          subtitle="Resep yang baru ditambahkan"
          recipes={latestRecipes}
          viewAllLink="/recipes?sort=newest"
        />

        {/* Features */}
        <FeaturesSection />

        {/* Popular Recipes */}
        <RecipeSection
          title="Paling Disukai"
          subtitle="Resep dengan rating tertinggi"
          recipes={popularRecipes}
          viewAllLink="/recipes?sort=popular"
          variant="featured"
        />

        {/* CTA */}
        <CTASection />
      </main>

      <Footer />
    </div>
  );
};

export default Index;
