import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Eye, EyeOff, ChefHat, Mail, Lock, User, ArrowRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { cn } from '@/lib/utils';

const loginSchema = z.object({
  email: z.string().trim().email({ message: "Email tidak valid" }),
  password: z.string().min(6, { message: "Password minimal 6 karakter" }),
});

const registerSchema = z.object({
  fullName: z.string().trim().min(2, { message: "Nama minimal 2 karakter" }).max(100, { message: "Nama maksimal 100 karakter" }),
  email: z.string().trim().email({ message: "Email tidak valid" }),
  password: z.string().min(6, { message: "Password minimal 6 karakter" }),
  confirmPassword: z.string().min(6, { message: "Konfirmasi password minimal 6 karakter" }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Password tidak cocok",
  path: ["confirmPassword"],
});

type LoginFormData = z.infer<typeof loginSchema>;
type RegisterFormData = z.infer<typeof registerSchema>;

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  
  const navigate = useNavigate();
  const { user, signIn, signUp } = useAuth();

  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: { fullName: '', email: '', password: '', confirmPassword: '' },
  });

  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleLogin = async (data: LoginFormData) => {
    setIsSubmitting(true);
    setAuthError(null);
    
    const { error } = await signIn(data.email, data.password);
    
    if (error) {
      if (error.message.includes('Invalid login credentials')) {
        setAuthError('Email atau password salah');
      } else if (error.message.includes('Email not confirmed')) {
        setAuthError('Email belum dikonfirmasi. Silakan cek inbox email Anda.');
      } else {
        setAuthError(error.message);
      }
    }
    
    setIsSubmitting(false);
  };

  const handleRegister = async (data: RegisterFormData) => {
    setIsSubmitting(true);
    setAuthError(null);
    
    const { error } = await signUp(data.email, data.password, data.fullName);
    
    if (error) {
      if (error.message.includes('User already registered')) {
        setAuthError('Email sudah terdaftar. Silakan login.');
      } else {
        setAuthError(error.message);
      }
    }
    
    setIsSubmitting(false);
  };

  const switchMode = () => {
    setIsLogin(!isLogin);
    setAuthError(null);
    loginForm.reset();
    registerForm.reset();
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel - Decorative */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden" style={{ background: 'var(--gradient-hero)' }}>
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-coral/20" />
        
        {/* Floating decorative elements */}
        <div className="absolute top-20 left-20 w-32 h-32 rounded-full bg-peach/30 blur-3xl animate-float" />
        <div className="absolute bottom-32 right-16 w-40 h-40 rounded-full bg-mint/30 blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/3 w-24 h-24 rounded-full bg-coral/20 blur-2xl animate-float" style={{ animationDelay: '4s' }} />
        
        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center items-center w-full p-12 text-center">
          <div className="w-24 h-24 rounded-3xl bg-card/80 backdrop-blur-sm flex items-center justify-center mb-8 shadow-lg animate-scale-in">
            <ChefHat className="w-12 h-12 text-primary" />
          </div>
          
          <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4 animate-slide-up">
            Resep Nusantara
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-md animate-slide-up stagger-1">
            Temukan ribuan resep masakan Indonesia autentik dan buat daftar belanja otomatis dengan mudah.
          </p>
          
          {/* Feature highlights */}
          <div className="mt-12 space-y-4 text-left animate-slide-up stagger-2">
            {[
              'Ribuan resep masakan Indonesia',
              'Daftar belanja otomatis',
              'Simpan resep favorit',
              'Rating & review komunitas',
            ].map((feature, index) => (
              <div key={index} className="flex items-center gap-3 text-foreground/80">
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span className="font-medium">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 md:p-12 bg-background">
        <div className="w-full max-w-md space-y-8 animate-fade-in">
          {/* Mobile Logo */}
          <div className="lg:hidden text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <ChefHat className="w-8 h-8 text-primary" />
            </div>
            <h1 className="font-display text-2xl font-bold">Resep Nusantara</h1>
          </div>

          {/* Form Header */}
          <div className="text-center lg:text-left">
            <h2 className="font-display text-3xl font-bold text-foreground">
              {isLogin ? 'Selamat Datang!' : 'Buat Akun Baru'}
            </h2>
            <p className="mt-2 text-muted-foreground">
              {isLogin 
                ? 'Masuk ke akun Anda untuk melanjutkan' 
                : 'Daftar untuk mulai menjelajahi resep'}
            </p>
          </div>

          {/* Error Message */}
          {authError && (
            <div className="p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm animate-scale-in">
              {authError}
            </div>
          )}

          {/* Login Form */}
          {isLogin ? (
            <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    {...loginForm.register('email')}
                    type="email"
                    placeholder="nama@email.com"
                    className={cn(
                      "pl-12 h-12 rounded-xl border-border bg-muted/50 focus:bg-background transition-colors",
                      loginForm.formState.errors.email && "border-destructive focus:ring-destructive/30"
                    )}
                  />
                </div>
                {loginForm.formState.errors.email && (
                  <p className="text-sm text-destructive">{loginForm.formState.errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    {...loginForm.register('password')}
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    className={cn(
                      "pl-12 pr-12 h-12 rounded-xl border-border bg-muted/50 focus:bg-background transition-colors",
                      loginForm.formState.errors.password && "border-destructive focus:ring-destructive/30"
                    )}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                {loginForm.formState.errors.password && (
                  <p className="text-sm text-destructive">{loginForm.formState.errors.password.message}</p>
                )}
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-12 rounded-xl text-base font-semibold"
                variant="hero"
              >
                {isSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    Masuk
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </Button>
            </form>
          ) : (
            /* Register Form */
            <form onSubmit={registerForm.handleSubmit(handleRegister)} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-sm font-medium">Nama Lengkap</Label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    {...registerForm.register('fullName')}
                    type="text"
                    placeholder="Nama lengkap Anda"
                    className={cn(
                      "pl-12 h-12 rounded-xl border-border bg-muted/50 focus:bg-background transition-colors",
                      registerForm.formState.errors.fullName && "border-destructive focus:ring-destructive/30"
                    )}
                  />
                </div>
                {registerForm.formState.errors.fullName && (
                  <p className="text-sm text-destructive">{registerForm.formState.errors.fullName.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    {...registerForm.register('email')}
                    type="email"
                    placeholder="nama@email.com"
                    className={cn(
                      "pl-12 h-12 rounded-xl border-border bg-muted/50 focus:bg-background transition-colors",
                      registerForm.formState.errors.email && "border-destructive focus:ring-destructive/30"
                    )}
                  />
                </div>
                {registerForm.formState.errors.email && (
                  <p className="text-sm text-destructive">{registerForm.formState.errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    {...registerForm.register('password')}
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Minimal 6 karakter"
                    className={cn(
                      "pl-12 pr-12 h-12 rounded-xl border-border bg-muted/50 focus:bg-background transition-colors",
                      registerForm.formState.errors.password && "border-destructive focus:ring-destructive/30"
                    )}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                {registerForm.formState.errors.password && (
                  <p className="text-sm text-destructive">{registerForm.formState.errors.password.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-sm font-medium">Konfirmasi Password</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    {...registerForm.register('confirmPassword')}
                    type={showConfirmPassword ? 'text' : 'password'}
                    placeholder="Ulangi password"
                    className={cn(
                      "pl-12 pr-12 h-12 rounded-xl border-border bg-muted/50 focus:bg-background transition-colors",
                      registerForm.formState.errors.confirmPassword && "border-destructive focus:ring-destructive/30"
                    )}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                {registerForm.formState.errors.confirmPassword && (
                  <p className="text-sm text-destructive">{registerForm.formState.errors.confirmPassword.message}</p>
                )}
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-12 rounded-xl text-base font-semibold"
                variant="hero"
              >
                {isSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    Daftar Sekarang
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </Button>
            </form>
          )}

          {/* Switch Mode */}
          <div className="text-center">
            <p className="text-muted-foreground">
              {isLogin ? 'Belum punya akun?' : 'Sudah punya akun?'}
              <button
                type="button"
                onClick={switchMode}
                className="ml-2 text-primary font-semibold hover:underline transition-colors"
              >
                {isLogin ? 'Daftar' : 'Masuk'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
