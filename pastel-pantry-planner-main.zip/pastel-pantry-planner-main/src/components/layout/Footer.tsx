import { Link } from "react-router-dom";
import { ChefHat, Instagram, Youtube, Facebook, Mail } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-muted/50 border-t border-border">
      <div className="container px-4 py-12 md:py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center">
                <ChefHat className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-display text-xl font-semibold">
                Resep<span className="text-primary">Ku</span>
              </span>
            </Link>
            <p className="text-sm text-muted-foreground mb-4">
              Platform resep masakan Indonesia dengan fitur daftar belanja otomatis.
            </p>
            <div className="flex items-center gap-3">
              <a href="#" className="w-9 h-9 rounded-full bg-card hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors duration-300">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-card hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors duration-300">
                <Youtube className="w-4 h-4" />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-card hover:bg-primary hover:text-primary-foreground flex items-center justify-center transition-colors duration-300">
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display font-semibold mb-4">Menu</h4>
            <ul className="space-y-2">
              {["Beranda", "Resep", "Kategori", "Populer"].map((item) => (
                <li key={item}>
                  <Link
                    to={item === "Beranda" ? "/" : `/${item.toLowerCase()}`}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Features */}
          <div>
            <h4 className="font-display font-semibold mb-4">Fitur</h4>
            <ul className="space-y-2">
              {["Daftar Belanja", "Menu Planner", "Favorit", "Tambah Resep"].map((item) => (
                <li key={item}>
                  <Link
                    to={`/${item.toLowerCase().replace(" ", "-")}`}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-display font-semibold mb-4">Bantuan</h4>
            <ul className="space-y-2">
              {["Tentang Kami", "FAQ", "Kontak", "Kebijakan Privasi"].map((item) => (
                <li key={item}>
                  <Link
                    to={`/${item.toLowerCase().replace(" ", "-")}`}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border mt-10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground text-center md:text-left">
            © 2024 ResepKu. Dibuat dengan ❤️ untuk pecinta masakan Indonesia.
          </p>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Mail className="w-4 h-4" />
            <span>hello@resepku.id</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
