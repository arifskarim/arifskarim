import { ShoppingCart, Calendar, Utensils, Heart, Smartphone, Users } from "lucide-react";

const features = [
  {
    icon: Utensils,
    title: "Ribuan Resep",
    description: "Koleksi lengkap resep Indonesia dari tradisional hingga modern",
    color: "bg-peach-light text-terracotta",
  },
  {
    icon: ShoppingCart,
    title: "Daftar Belanja Otomatis",
    description: "Generate daftar belanja dari resep pilihan dengan konversi unit otomatis",
    color: "bg-mint-light text-secondary-foreground",
  },
  {
    icon: Calendar,
    title: "Menu Planner",
    description: "Rencanakan menu harian atau mingguan dengan mudah",
    color: "bg-butter text-foreground",
  },
  {
    icon: Heart,
    title: "Simpan Favorit",
    description: "Bookmark resep favorit dan akses kapan saja",
    color: "bg-coral-light text-accent-foreground",
  },
  {
    icon: Smartphone,
    title: "Mobile Ready",
    description: "Akses dari mana saja dengan tampilan mobile-friendly",
    color: "bg-lavender text-foreground",
  },
  {
    icon: Users,
    title: "Komunitas",
    description: "Bagikan resep dan dapatkan inspirasi dari pengguna lain",
    color: "bg-secondary text-secondary-foreground",
  },
];

export const FeaturesSection = () => {
  return (
    <section className="py-16 md:py-24">
      <div className="container px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="section-title mb-4">Fitur Unggulan</h2>
          <p className="text-muted-foreground">
            Semua yang kamu butuhkan untuk pengalaman memasak yang lebih menyenangkan
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group relative p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-500 hover:-translate-y-1 hover:shadow-hover animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Icon */}
              <div className={`w-14 h-14 rounded-xl ${feature.color} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-500`}>
                <feature.icon className="w-7 h-7" />
              </div>

              {/* Content */}
              <h3 className="font-display text-xl font-semibold mb-2">
                {feature.title}
              </h3>
              <p className="text-muted-foreground">
                {feature.description}
              </p>

              {/* Hover decoration */}
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-primary/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
