import { useState } from "react";
import { Search, ArrowRight, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

export const HeroSection = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/recipes?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const popularSearches = ["Nasi Goreng", "Rendang", "Ayam Geprek", "Soto Ayam"];

  return (
    <section className="relative min-h-[80vh] flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-hero" />
      
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-primary/20 rounded-full blur-3xl animate-pulse-soft" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-coral/20 rounded-full blur-3xl animate-pulse-soft" style={{ animationDelay: "1s" }} />
      <div className="absolute top-1/2 left-1/4 w-48 h-48 bg-mint/30 rounded-full blur-2xl animate-float" />
      
      {/* Floating Food Emojis */}
      <div className="absolute top-32 right-[15%] text-5xl animate-float opacity-60" style={{ animationDelay: "0.5s" }}>🍳</div>
      <div className="absolute top-[60%] left-[10%] text-4xl animate-float opacity-50" style={{ animationDelay: "1s" }}>🥗</div>
      <div className="absolute bottom-32 right-[25%] text-5xl animate-float opacity-60" style={{ animationDelay: "1.5s" }}>🍜</div>
      <div className="absolute top-[40%] right-[8%] text-3xl animate-float opacity-50" style={{ animationDelay: "2s" }}>🥘</div>

      {/* Content */}
      <div className="container relative z-10 px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-card/80 backdrop-blur-sm text-sm font-medium mb-8 animate-fade-in shadow-soft">
            <Sparkles className="w-4 h-4 text-primary" />
            <span>Lebih dari 500+ resep Indonesia autentik</span>
          </div>

          {/* Heading */}
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 animate-slide-up">
            Masak Lebih Mudah,
            <br />
            <span className="gradient-text">Belanja Lebih Cerdas</span>
          </h1>

          {/* Subheading */}
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-xl mx-auto animate-slide-up stagger-1">
            Temukan ribuan resep lezat dan buat daftar belanja otomatis dalam sekejap. 
            Dari dapur tradisional hingga kreasi modern.
          </p>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="animate-slide-up stagger-2">
            <div className="relative max-w-xl mx-auto">
              <div className="flex items-center gap-3 px-6 py-4 rounded-2xl bg-card shadow-card border border-border focus-within:ring-2 focus-within:ring-primary/30 focus-within:border-primary transition-all duration-300">
                <Search className="w-6 h-6 text-muted-foreground flex-shrink-0" />
                <input
                  type="text"
                  placeholder="Mau masak apa hari ini?"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 bg-transparent border-none outline-none text-lg placeholder:text-muted-foreground"
                />
                <Button type="submit" className="btn-primary rounded-xl px-6">
                  Cari
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          </form>

          {/* Popular Searches */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-6 animate-slide-up stagger-3">
            <span className="text-sm text-muted-foreground">Populer:</span>
            {popularSearches.map((term) => (
              <button
                key={term}
                onClick={() => navigate(`/recipes?q=${encodeURIComponent(term)}`)}
                className="px-3 py-1 rounded-full text-sm font-medium bg-card/60 hover:bg-primary hover:text-primary-foreground transition-all duration-300 backdrop-blur-sm"
              >
                {term}
              </button>
            ))}
          </div>

          {/* Stats */}
          <div className="flex flex-wrap items-center justify-center gap-8 mt-16 animate-slide-up stagger-4">
            <div className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold text-foreground">500+</div>
              <div className="text-sm text-muted-foreground">Resep</div>
            </div>
            <div className="w-px h-12 bg-border hidden sm:block" />
            <div className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold text-foreground">10K+</div>
              <div className="text-sm text-muted-foreground">Pengguna</div>
            </div>
            <div className="w-px h-12 bg-border hidden sm:block" />
            <div className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold text-foreground">4.9</div>
              <div className="text-sm text-muted-foreground">Rating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
