import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Category } from "@/types/recipe";
import { CategoryCard } from "@/components/recipe/CategoryCard";
import { Button } from "@/components/ui/button";

interface CategorySectionProps {
  categories: Category[];
}

export const CategorySection = ({ categories }: CategorySectionProps) => {
  return (
    <section className="py-16 md:py-24 bg-vanilla/50">
      <div className="container px-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <h2 className="section-title">Jelajahi Kategori</h2>
            <p className="text-muted-foreground mt-2">
              Temukan resep berdasarkan kategori favoritmu
            </p>
          </div>
          <Link to="/categories">
            <Button variant="ghost" className="group gap-2 hover:bg-primary hover:text-primary-foreground rounded-xl">
              Semua Kategori
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>

        {/* Category Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {categories.slice(0, 10).map((category, index) => (
            <div
              key={category.id}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <CategoryCard category={category} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
