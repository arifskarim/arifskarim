import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { Recipe } from "@/types/recipe";
import { RecipeCard } from "@/components/recipe/RecipeCard";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface RecipeSectionProps {
  title: string;
  subtitle?: string;
  recipes: Recipe[];
  viewAllLink: string;
  variant?: "default" | "featured";
}

export const RecipeSection = ({
  title,
  subtitle,
  recipes,
  viewAllLink,
  variant = "default",
}: RecipeSectionProps) => {
  return (
    <section className={cn(
      "py-16 md:py-24",
      variant === "featured" && "bg-muted/50"
    )}>
      <div className="container px-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <h2 className="section-title">{title}</h2>
            {subtitle && (
              <p className="text-muted-foreground mt-2">{subtitle}</p>
            )}
          </div>
          <Link to={viewAllLink}>
            <Button variant="ghost" className="group gap-2 hover:bg-primary hover:text-primary-foreground rounded-xl">
              Lihat Semua
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>

        {/* Recipe Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {recipes.map((recipe, index) => (
            <div
              key={recipe.id}
              className="animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <RecipeCard recipe={recipe} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
