import { Link } from "react-router-dom";
import { ArrowRight, ChefHat } from "lucide-react";
import { Button } from "@/components/ui/button";

export const CTASection = () => {
  return (
    <section className="py-20 md:py-28 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-primary opacity-90" />
      
      {/* Decorative */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-card/10 rounded-full blur-2xl" />
      <div className="absolute bottom-10 right-10 w-48 h-48 bg-card/10 rounded-full blur-2xl" />
      <div className="absolute top-1/2 left-1/3 text-6xl opacity-20 animate-float">🍳</div>
      <div className="absolute top-1/4 right-1/4 text-5xl opacity-20 animate-float" style={{ animationDelay: "1s" }}>🥘</div>

      <div className="container relative z-10 px-4">
        <div className="max-w-3xl mx-auto text-center">
          {/* Icon */}
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-card/20 backdrop-blur-sm mb-8">
            <ChefHat className="w-8 h-8 text-card" />
          </div>

          {/* Heading */}
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-card mb-6">
            Siap Mulai Memasak?
          </h2>

          <p className="text-lg text-card/80 mb-10 max-w-xl mx-auto">
            Bergabunglah dengan ribuan pengguna lain dan nikmati kemudahan memasak 
            dengan fitur daftar belanja otomatis kami.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/recipes">
              <Button size="lg" className="rounded-xl bg-card text-primary hover:bg-card/90 shadow-lg px-8 gap-2">
                Jelajahi Resep
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
            <Link to="/add-recipe">
              <Button size="lg" variant="outline" className="rounded-xl border-card/30 text-card hover:bg-card/10 px-8">
                Bagikan Resepmu
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};
