import { useState } from "react";
import { Link } from "react-router-dom";
import { Heart, Clock, Star, ShoppingCart, ChefHat } from "lucide-react";
import { Recipe } from "@/types/recipe";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

// Import recipe images
import nasiGorengImg from "@/assets/recipes/nasi-goreng.jpg";
import rendangImg from "@/assets/recipes/rendang.jpg";
import sotoAyamImg from "@/assets/recipes/soto-ayam.jpg";
import gadoGadoImg from "@/assets/recipes/gado-gado.jpg";
import esCendolImg from "@/assets/recipes/es-cendol.jpg";
import mieGorengImg from "@/assets/recipes/mie-goreng.jpg";
import ayamGeprekImg from "@/assets/recipes/ayam-geprek.jpg";

const recipeImages: Record<string, string> = {
  "1": nasiGorengImg,
  "2": rendangImg,
  "3": sotoAyamImg,
  "4": gadoGadoImg,
  "5": esCendolImg,
  "6": mieGorengImg,
  "7": ayamGeprekImg,
};

interface RecipeCardProps {
  recipe: Recipe;
  onAddToList?: (recipe: Recipe) => void;
}

export const RecipeCard = ({ recipe, onAddToList }: RecipeCardProps) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const [isImageLoaded, setIsImageLoaded] = useState(false);

  const totalTime = recipe.prepTime + recipe.cookTime;
  const imageUrl = recipeImages[recipe.id] || recipe.image;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "mudah":
        return "bg-mint text-secondary-foreground";
      case "sedang":
        return "bg-butter text-foreground";
      case "sulit":
        return "bg-coral text-accent-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="recipe-card group">
      {/* Image Container */}
      <div className="recipe-card-image aspect-[4/3] relative">
        {!isImageLoaded && (
          <div className="absolute inset-0 bg-muted animate-pulse" />
        )}
        <img
          src={imageUrl}
          alt={recipe.title}
          className={cn(
            "transition-opacity duration-500",
            isImageLoaded ? "opacity-100" : "opacity-0"
          )}
          onLoad={() => setIsImageLoaded(true)}
        />
        
        {/* Overlay Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Floating Badge */}
        <div className={cn("floating-badge", getDifficultyColor(recipe.difficulty))}>
          {recipe.difficulty.charAt(0).toUpperCase() + recipe.difficulty.slice(1)}
        </div>

        {/* Favorite Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            setIsFavorite(!isFavorite);
          }}
          className={cn(
            "absolute top-4 left-4 p-2 rounded-full backdrop-blur-sm transition-all duration-300",
            isFavorite 
              ? "bg-coral text-card" 
              : "bg-background/80 text-foreground hover:bg-coral hover:text-card"
          )}
        >
          <Heart className={cn("w-4 h-4", isFavorite && "fill-current")} />
        </button>

        {/* Trending Badge */}
        {recipe.isTrending && (
          <div className="absolute bottom-4 left-4 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold flex items-center gap-1">
            <ChefHat className="w-3 h-3" />
            Trending
          </div>
        )}

        {/* Quick Add to List - appears on hover */}
        <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
          <Button
            size="sm"
            onClick={(e) => {
              e.preventDefault();
              onAddToList?.(recipe);
            }}
            className="rounded-full bg-card/90 text-foreground hover:bg-primary hover:text-primary-foreground backdrop-blur-sm shadow-lg"
          >
            <ShoppingCart className="w-4 h-4 mr-1" />
            Belanja
          </Button>
        </div>
      </div>

      {/* Content */}
      <Link to={`/recipe/${recipe.id}`} className="block p-4">
        {/* Category & Time */}
        <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
          <span className="font-medium text-primary">{recipe.category}</span>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{totalTime} menit</span>
          </div>
        </div>

        {/* Title */}
        <h3 className="font-display text-lg font-semibold mb-2 line-clamp-2 group-hover:text-primary transition-colors duration-300">
          {recipe.title}
        </h3>

        {/* Description */}
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
          {recipe.description}
        </p>

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-border">
          {/* Rating */}
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-butter text-butter" />
            <span className="font-semibold">{recipe.rating}</span>
            <span className="text-sm text-muted-foreground">
              ({recipe.reviewCount})
            </span>
          </div>

          {/* Favorites */}
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Heart className="w-4 h-4 text-coral" />
            <span>{recipe.favoriteCount}</span>
          </div>
        </div>
      </Link>
    </div>
  );
};
