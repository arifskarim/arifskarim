import { Link } from "react-router-dom";
import { Category } from "@/types/recipe";
import { cn } from "@/lib/utils";

interface CategoryCardProps {
  category: Category;
  variant?: "default" | "compact";
}

const categoryColors: Record<string, string> = {
  "Sarapan": "bg-butter",
  "Makan Siang": "bg-peach-light",
  "Makan Malam": "bg-coral-light",
  "Camilan": "bg-lavender",
  "Minuman": "bg-mint-light",
  "Sup & Soto": "bg-sage/30",
  "Nasi & Mie": "bg-peach-light",
  "Seafood": "bg-secondary",
  "Ayam & Bebek": "bg-butter",
  "Vegetarian": "bg-mint-light",
};

export const CategoryCard = ({ category, variant = "default" }: CategoryCardProps) => {
  const bgColor = categoryColors[category.name] || "bg-muted";

  if (variant === "compact") {
    return (
      <Link
        to={`/recipes?category=${encodeURIComponent(category.name)}`}
        className="category-pill flex-shrink-0"
      >
        <span className="text-lg">{category.icon}</span>
        <span>{category.name}</span>
      </Link>
    );
  }

  return (
    <Link
      to={`/recipes?category=${encodeURIComponent(category.name)}`}
      className={cn(
        "group relative overflow-hidden rounded-2xl p-6 transition-all duration-500",
        "hover:-translate-y-1 hover:shadow-hover",
        bgColor
      )}
    >
      <div className="flex flex-col items-center text-center gap-3">
        {/* Icon */}
        <div className="text-4xl transform group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500">
          {category.icon}
        </div>
        
        {/* Name */}
        <h3 className="font-display font-semibold text-foreground">
          {category.name}
        </h3>
        
        {/* Recipe Count */}
        <span className="text-sm text-muted-foreground">
          {category.recipeCount} resep
        </span>
      </div>

      {/* Decorative circle */}
      <div className="absolute -bottom-8 -right-8 w-24 h-24 rounded-full bg-background/20 group-hover:scale-150 transition-transform duration-700" />
    </Link>
  );
};
